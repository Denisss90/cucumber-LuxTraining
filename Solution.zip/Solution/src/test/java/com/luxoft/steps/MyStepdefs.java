package com.luxoft.steps;

import com.luxoft.web.CataloguePage;
import com.luxoft.web.ContactsPage;
import com.luxoft.web.LuxTrainingMainPage;
import com.luxoft.web.TimeTablePage;
import io.cucumber.java.ru.*;

import java.util.List;

public class MyStepdefs {
    private LuxTrainingMainPage luxTrainingMainPage = new LuxTrainingMainPage(Hooks.driver);
    private TimeTablePage timeTablePage;
    private ContactsPage contactsPage;
    private CataloguePage cataloguePage;

    @Дано("открыть вкладку Расписание")
    public void открыть_вкладку_Расписание() {
        timeTablePage = luxTrainingMainPage.openTimeTablePage();
    }


    @Тогда("отображается кнопка {string}")
    public void отображаетсяКнопка(String arg0) {
        timeTablePage.isElementDisplayedByLinkText(arg0);
    }

    @Дано("открыть вкладку Контакты")
    public void открытьВкладкуКонтакты() {
        contactsPage = luxTrainingMainPage.openContactsPage();
    }

    @Тогда("^(отобража.тся|не отобража.тся) кнопк.$")
    public void отображаютсяКнопки(String visible, List<String> args) {
        for(String value: args){
            if(visible.contains("не "))
                contactsPage.isElementDisplayedByLinkText(value, false);
            else
                contactsPage.isElementDisplayedByLinkText(value, true);
        }
    }

    @Если("открыть вкладку Каталог")
    public void открытьВкладкуКаталог() {
        cataloguePage = luxTrainingMainPage.openCatalogue();
    }

    @И("найти курс {string}")
    public void найтиКурс(String arg0) {
        cataloguePage.searchFor(arg0);
    }


    @То("^отображается (?:ссылка на курс|описание курса) \"([^\"]*)\"$")
    public void отображаетсяСсылкаНаКурс(String arg0) {
        cataloguePage.isCourseNameDisplayed(arg0);
    }
}
