package com.luxoft.steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Hooks {
    public static WebDriver driver;

    @Before
    public void startUp(){
        if (driver==null) {
            System.setProperty("webdriver.chrome.driver", "lib/chromedriver");
            WebDriver driver = new ChromeDriver();
            Hooks.driver = driver;
            driver.manage().window().maximize();
        }
        driver.navigate().to("https://www.luxoft-training.ru/");
    }

    @Before(value = "@ex2")
    public void ex2Before(Scenario scenario){
        System.out.println(scenario.getName());
    }

    @After(value = "@ex2", order = 5000)
    public void afterEx21(){
        System.out.println("after hook with order 5000");
    }

    @After(value = "@ex2", order = 4000)
    public void afterEx22(){
        System.out.println("after hook with order 4000");
    }

    @Before(value = "@ex3")
    public void ex3Before(Scenario scenario){
        System.out.println(scenario.getName());
    }

    @Before(value = "@ex4")
    public void ex4Before(Scenario scenario){
        System.out.println(scenario.getName());
    }

    @After
    public void makeScreenshot(Scenario scenario){
        if (scenario.isFailed()) {
            // Take a screenshot...
            final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", scenario.getName()); // ... and embed it in the report.
        }
    }

}
