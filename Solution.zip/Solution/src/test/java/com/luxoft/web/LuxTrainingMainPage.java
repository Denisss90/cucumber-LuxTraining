package com.luxoft.web;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LuxTrainingMainPage {

    private WebDriver driver;


    public LuxTrainingMainPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(linkText = "Расписание")
    private WebElement timetable;

    @FindBy(linkText = "Контакты")
    private WebElement contacts;

    @FindBy(linkText = "Каталог")
    private WebElement catalogue;

    public TimeTablePage openTimeTablePage(){
        timetable.click();
        return new TimeTablePage(driver);
    }

    public ContactsPage openContactsPage(){
        contacts.click();
        return new ContactsPage(driver);
    }

    public CataloguePage openCatalogue(){
        catalogue.click();
        return new CataloguePage(driver);
    }
}
