package com.luxoft.web;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CataloguePage {

    public CataloguePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    private WebDriver driver;

    @FindBy(name = "qcat")
    private WebElement searchField;

    public void searchFor(String text){
        searchField.sendKeys(text);
        searchField.sendKeys(Keys.ENTER);
    }

    public void isCourseNameDisplayed(String name){
        Assertions.assertTrue(driver.findElement(By.linkText(name)).isDisplayed());
    }
}
