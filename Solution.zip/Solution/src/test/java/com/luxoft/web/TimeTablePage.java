package com.luxoft.web;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TimeTablePage {

    private WebDriver driver;

    @FindBy(linkText = "Расписание")
    private WebElement timetable;

    @FindBy(linkText = "Расписание")
    private WebElement seminars;

    @FindBy(linkText = "Расписание")
    private WebElement onlineCourses;

    public TimeTablePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void isElementDisplayedByLinkText(String text){
        Assertions.assertTrue(driver.findElement(By.linkText(text)).isDisplayed());
    }
}
