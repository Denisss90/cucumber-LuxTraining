package app;

public class Calc {

    private int x;
    private int y;

    public boolean isYDivideX(int x, int y){
        return x % y == 0;
    }
}
