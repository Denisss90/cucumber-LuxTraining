package com.luxoft.steps;

import com.luxoft.dto.Example;
import io.cucumber.java.en.*;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;


public class StepdefsRest {
    RequestSpecification requestSpecification;
    Response response;

    @Given("base URL {string}")
    public void baseURLHttpsJsonplaceholderTypicodeCom(String url) {
        requestSpecification = given().baseUri(url);
    }

    @When("I send get request to {string} with parameter {string}")
    public void iSendGetRequestToPostsWithParameter(String arg0, String arg1) {
        response = given(requestSpecification)
                .pathParam("posts", arg0)
                .pathParam("id", arg1)
                .when().get("{posts}/{id}");
        Example model = response.as(Example.class);
        System.out.println(model);
    }


    @Then("I receive status {int}")
    public void iReceiveStatus(int arg0) {
       Assertions.assertEquals(response.getStatusCode(), arg0);
    }
}