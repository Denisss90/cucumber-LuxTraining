package com.luxoft.steps;

import com.luxoft.Auxillary;
import com.luxoft.dto.Example;
import com.luxoft.pages.HomePage;
import com.luxoft.pages.ResultsPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import static io.restassured.RestAssured.given;


public class StepdefsWeb {
    private WebDriver driver = Hooks.auxillary.getWebDriver().get();
    HomePage homePage = new HomePage(driver);
    ResultsPage resultsPage = new ResultsPage(driver);

    @Given("Google home page is opened")
    public void googleHomePageIsOpened() {
        Hooks.auxillary.getWebDriver().get().navigate().to("https://google.com");
    }

    @When("I search for {string}")
    public void iSearchFor(String arg0) {
//        Auxillary.webDriver.findElement(By.name("q")).sendKeys(arg0);
//        Auxillary.webDriver.findElement(By.name("q")).sendKeys(Keys.ENTER);
        homePage.searchFor(arg0);
    }

    @Then("element {string} is displayed")
    public void elementIsDisplayed(String arg0) {
        resultsPage.isElementDisplayed(resultsPage.getFromMap(arg0));
    }
}