package com.luxoft.steps;

import app.Calc;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.shadow.com.univocity.parsers.annotations.Format;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.MatcherAssert.assertThat;

public class MyStepdefs {
    int x;
    int y;

    private Map<String,String> actual = new HashMap<String,String>()
            {{
                put("user1", "password");
                put("user2", "qwerty");
//                put("user3", "12345");
            }}
    ;

    @When("compare datatables")
    public void compareDatatables(Map<String,String> expected) {
       assertThat(expected, equalTo(actual));
    }

    @Given("print text to console {string}")
    public void printTextToConsole(String arg0) {
        System.out.println(arg0);
    }

    @Given("read data from file {string}")
    public void readDataFromFile(String arg0) {
        //code how to read and parse file

    }

    @Given("Print table values")
    public void printTableValues(List<Float> data) {
        data.forEach(System.out::println);
    }

    @When("print user data")
    public void printUserData(List<List<String>> data) {
        for(int i=0;i<data.size();i++){
            System.out.println(data.get(i).get(0) + " - " + data.get(i).get(1));
        }
        throw new PendingException();
    }

    @When("print user data map")
    public void printUserDataMap(Map<String, Integer> data) {
        data.forEach((K,V) -> System.out.println(K + " - " + (V+2)));
    }

    @When("print user data datatable")
    public void printUserDataDatatable(DataTable table) {
        List<List<String>> dt = table.asLists();
        System.out.println(dt);
    }

    @Given("Find if received data matches datatable")
    public void findIfReceivedDataMatchesDatatable(List<Double> expected) {
        List<Double> actual = Arrays.asList(1.5, 3.0);
        actual.forEach(value -> assertThat(expected, hasItem(value)));
    }

    @Then("^creation date is (.+)$")
    public void creationDateIs(String arg) throws ParseException {
        Date date1=new SimpleDateFormat("dd.MM.yyyy").parse(arg);
        System.out.println(date1);
    }

    @Given("x = {int}")
    public void x(int arg0) {
        x = arg0;
    }

    @Given("y = {int}")
    public void y(int arg0) {
        y = arg0;
    }

    @Then("y divides x")
    public void yDividesX() {
        Calc calc = new Calc();
        Assertions.assertTrue(calc.isYDivideX(x,y));
    }
}
