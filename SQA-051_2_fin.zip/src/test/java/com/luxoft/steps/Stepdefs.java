package com.luxoft.steps;

import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;

public class Stepdefs {
    private int distance;
    private String sentence = "";
//    boolean hunger = true;

    @Given("^.ucy is in (\\d+) m from Sean$")
    public void lucy_is_in_m_from_sean(Integer int1) {
        distance = int1;
    }

    @When("^Sean shouts \"([^\"]*)\"$")
    public void seanShoutsFreeBagels(String arg0) {
        sentence = arg0;
    }

    @Then("^Lucy (hear|not hear) Sean (?:message|letter|word)$")
    public void lucyHearSeanMessage(String arg0) {
        if(arg0.equalsIgnoreCase("hear"))
            Assertions.assertTrue(distance<15);
        else{
            if(!Hooks.auxillary.getHunger().get()) {
                System.out.println("Lucy is not hungry");
            }else {
                Assertions.assertFalse(distance < 15);
            }
        }
    }



    @But("Lucy is not hungry")
    public void lucyIsNotHungry() {
        Hooks.auxillary.getHunger().set(false);
    }

//    @Then("Lucy not hear Sean message")
//    public void lucyNotHearSeanMessage() {
//        if(!hunger) {
//            System.out.println("Lucy is not hungry");
//        }else {
//            Assertions.assertFalse(distance < 15);
//        }
//    }

    @And("Lucy goes home")
    public void lucyGoesHome() {
    }

}