package com.luxoft.steps;

import com.luxoft.Auxillary;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.Status;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Hooks {
    public static Auxillary auxillary;

    @Before(value = "@tag1 and @tag2", order = 30)
    public void firstHook(){
        System.out.println("this is first before hook");
    }

    @Before(order = 5, value = "@shout")
    public void secondHook(){
        System.out.println("this is second before hook");
    }

    @After(order = 9001)
    public void tearDown(Scenario scenario){
        System.out.println("this is after hook 9001");
    }

    @After(order = 9005)
    public void tearDown1(){
        System.out.println("this is after hook 9005");
    }

    @Before(value = "@web or @google", order = 1)
    public void startBrowser(){
        if(auxillary==null)
            auxillary = new Auxillary();
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.setHeadless(false);
        WebDriver driver = new ChromeDriver(options);
//        Auxillary.webDriver = driver;
        auxillary.getWebDriver().set(driver);


    }

    @After(order = 1)
    public void cleanUp(Scenario scenario)  {
        if (scenario.isFailed()) {
            // Take a screenshot...
//            final byte[] screenshot = ((TakesScreenshot) Auxillary.webDriver).getScreenshotAs(OutputType.BYTES);
            final byte[] screenshot = ((TakesScreenshot) auxillary.getWebDriver().get()).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", scenario.getName()); // ... and embed it in the report.
        }
    }
}
