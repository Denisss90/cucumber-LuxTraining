package com.luxoft;

import org.openqa.selenium.WebDriver;

public class Auxillary {

//    public static boolean hunger = true;
//    public static WebDriver webDriver;

    public ThreadLocal<Boolean> hunger = ThreadLocal.withInitial(()-> true);
    public ThreadLocal<WebDriver> webDriver = ThreadLocal.withInitial(()->null);


    //Getters and Setters
    public ThreadLocal<WebDriver> getWebDriver() {
        return webDriver;
    }

    public void setWebDriver(ThreadLocal<WebDriver> webDriver) {
        this.webDriver = webDriver;
    }

    public ThreadLocal<Boolean> getHunger() {
        return hunger;
    }

    public void setHunger(ThreadLocal<Boolean> hunger) {
        this.hunger = hunger;
    }
}
