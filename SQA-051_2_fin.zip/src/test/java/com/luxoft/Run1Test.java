package com.luxoft;

import com.luxoft.steps.Hooks;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features ="src/test/java/com/luxoft/features",
        tags = "@web",
        glue = "com.luxoft.steps",
        plugin = {"pretty",
                "html:target/cucumber-reports/cucumber-pretty",
                "json:target/cucumber1.json"
        }
)
public class Run1Test {

//        @AfterClass
//        public static void tearDown(){
//                Hooks.auxillary.getWebDriver().get().quit();
//        }
}
