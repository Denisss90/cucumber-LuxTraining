package com.luxoft.pages;

import com.luxoft.Auxillary;
import com.luxoft.steps.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.HashMap;
import java.util.Map;

public class ResultsPage extends CommonPage{


    private WebDriver driver;

    Map<String, By> elementMap = new HashMap<String, By>(){{
       put("Search field", By.name("q"));
       put("link", By.xpath("//span[text()='Selenium Webdriver Manager - Заметки Автоматизатора']"));
    }};

    public ResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    public WebElement getFromMap(String elementName) {
        return Hooks.auxillary.getWebDriver().get().findElement(elementMap.get(elementName));
    }
}
