package com.luxoft;

public class Auxillary {
    public static boolean hunger = true;
}
